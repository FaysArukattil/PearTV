# Lean TV

A native Android TV app (Kotlin, Jetpack Compose) that removes preinstalled bloat, switches off
trackers and speeds up your TV, with a full restore path. Built first for the Xiaomi Mi TV
(MiTV-MOOQ0, Android 10) and designed to work on other Android TV / Google TV / Fire TV devices.

## How it works
The app is not allowed to uninstall system apps itself. Instead it talks to the TV's own ADB
daemon (adbd) over TCP, from the TV itself, using the `dadb` library. This is the same channel
a computer uses with `adb shell`. It needs **USB debugging** on, and the TV shows a one-time
"Allow USB debugging?" prompt for the app's key.

- Remove: `pm uninstall -k --user 0 <package>` (does not touch the system partition)
- Restore: `cmd package install-existing --user 0 <package>`
- Disable (alternative): `pm disable-user --user 0 <package>`, undone with `pm enable`
- Tweaks: `settings put global ...` (animation scales, Private DNS), values saved first and restored on reset

## Build and install
1. Open this folder in **Android Studio** (Ladybug or newer, JDK 17). Let Gradle sync.
2. Connect to the TV: `adb connect <TV_IP>:5555` (Settings > Network shows the IP).
3. Run the `app` configuration on the TV, or build an APK:
   `Build > Build Bundle(s) / APK(s) > Build APK(s)` (use the `release` variant for the optimized build).
4. Sideload: `adb install app/build/outputs/apk/release/app-release.apk`
   The app appears on the TV home screen (or under Settings > Apps if your launcher hides sideloaded apps).

If R8 fails on release, set `isMinifyEnabled = false` in `app/build.gradle.kts`.

## First run on the TV
1. Settings > Device Preferences > About, click Build 7 times.
2. Developer options > USB debugging ON.
3. Open Lean TV and choose Allow (tick Always allow) on the prompt.

If it reports "The TV isn't accepting debug connections", run once from a computer on the same Wi-Fi:
`adb tcpip 5555`, then try again. (Not all TVs need this.)

## Safety model
- Core Android, Google Play services, chipset vendors, live TV inputs, the only launcher and the only
  keyboard are never listed.
- Only `app/src/main/assets/catalog.json` can label an app Recommended or Optional. Everything else
  is "Advanced" and never preselected.
- Every removal is written to a journal. "Restore all" also compares against a snapshot of the
  system apps taken before the first change.
- If something goes wrong and the remote stops working, plug in a USB keyboard/mouse, or from a
  computer run: `adb connect <TV_IP>:5555` then `adb shell cmd package install-existing --user 0 <package>`.
  A factory reset from the TV's own Settings always brings everything back.

## Growing the catalog
The bundled catalog is deliberately small and conservative. After you run a scan on a TV, send the
list of "Advanced" apps; add entries to `catalog.json` as they are verified on real devices:

    { "pkg": "com.example.app", "name": "Example", "tier": "RECOMMENDED", "why": "Plain-language reason." }

A later step can host this JSON remotely so it updates without a new APK.

## Project layout
    app/src/main/java/com/leantv/app/
      adb/AdbClient.kt        ADB connection and shell
      data/                   models, catalog, scanner (safety rules), device probe, journal, tweaks
      ui/                     ViewModel, theme, components, screens
    app/src/main/assets/catalog.json
