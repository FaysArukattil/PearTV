# Changelog

All notable changes to the LeanTV project will be documented in this file.

## [Phase 1 - Installed Apps List & Uninstaller] - 2026-11-10

### Added
- Added `REQUEST_DELETE_PACKAGES` permission in `AndroidManifest.xml`.
- Created `InstalledAppModels.kt` containing `InstalledAppInfo`, `AppTypeFilter`, and `AppSortOrder`.
- Created `IconCache.kt` providing high-performance in-memory LRU caching of app icons with async background decoding.
- Created `InstalledAppsScanner.kt` to inspect installed packages, calculate APK size (including splits), detect system/user status, and check launch intent availability.
- Created `InstalledAppsScreen.kt` with TV remote navigation, search bar, All/User/System filters, sorting by name/size/install date, and quick action dialogs.
- Implemented remote-safe uninstallation flow via `Intent.ACTION_DELETE` with confirmation dialog focusing Cancel by default.
- Integrated Installed Apps into the navigation rail and screen router with auto-refresh on resume.

## [Phase 0 - Baseline Analysis] - 2026-11-10

### Added
- Created `ARCHITECTURE.md` with complete module architecture and planned component breakdown.
- Created `PROGRESS.md` with phase tracking, decision logs, and resumption instructions.
- Validated baseline build with Kotlin 2.0.21, AGP 8.7.3, compileSdk 35, and targetSdk 34.
