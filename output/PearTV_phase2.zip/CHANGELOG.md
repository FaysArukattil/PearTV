# Changelog

All notable changes to the LeanTV project will be documented in this file.

## [Phase 2 - Custom Launcher (Apple tvOS Style)] - 2026-11-10

### Added
- Declared `HomeActivity` in `AndroidManifest.xml` with `singleTask` launchMode and intent filters for `HOME`, `DEFAULT`, `LEANBACK_LAUNCHER`, and `LAUNCHER`.
- Implemented `LauncherViewModel.kt` managing launchable apps, featured carousel, favorites persistence in `Journal`, live clock/date ticker, and default launcher flow.
- Implemented `HomeScreen.kt` with Apple tvOS-inspired design:
  - Top header with live digital clock, date, and quick shortcut pills (Tools, Settings).
  - Ambient gradient backdrop with focus-reactive radial glow.
  - Featured Apps row with large 280x160dp cards, 1.08x scale elevation, and amber glowing border.
  - Favorites and All Applications rows with fast 60fps horizontal scrolling and cached icons.
  - Remote Menu key (`KEYCODE_MENU`) / long-click action dialog for Open, Favorite toggle, Uninstall, and App Info.
  - "Set as Default Launcher" prompt using Android Q `RoleManager.ROLE_HOME` and `ACTION_HOME_SETTINGS` fallback.
- Added quick "Home screen" jump button to `MainActivity` navigation rail.

## [Phase 1 - Installed Apps List & Uninstaller] - 2026-11-10

### Added
- Added `REQUEST_DELETE_PACKAGES` permission in `AndroidManifest.xml`.
- Created `InstalledAppModels.kt` containing `InstalledAppInfo`, `AppTypeFilter`, and `AppSortOrder`.
- Created `IconCache.kt` providing high-performance in-memory LRU caching of app icons with async background decoding.
- Created `InstalledAppsScanner.kt` to inspect installed packages, calculate APK size (including splits), detect system/user status, and check launch intent availability.
- Created `InstalledAppsScreen.kt` with TV remote navigation, search bar, All/User/System filters, sorting by name/size/install date, and quick action dialogs.
- Implemented remote-safe uninstallation flow via `Intent.ACTION_DELETE` with confirmation dialog focusing Cancel by default.
- Integrated Installed Apps into the navigation rail and screen router with auto-refresh on resume.

## [Phase 0 - Baseline Analysis] - 2026-11-10

### Added
- Created `ARCHITECTURE.md` with complete module architecture and planned component breakdown.
- Created `PROGRESS.md` with phase tracking, decision logs, and resumption instructions.
- Validated baseline build with Kotlin 2.0.21, AGP 8.7.3, compileSdk 35, and targetSdk 34.
