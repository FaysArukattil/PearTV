# LeanTV — Development Progress

## 1. Project Overview & Architecture Summary
LeanTV is a native Android TV system manager and custom launcher built using Jetpack Compose, Kotlin 2.0.21, and AndroidX libraries (minSdk 26, targetSdk 34, compileSdk 35). It provides:
1. System optimization and debloating capabilities via on-device ADB.
2. Full installed application browsing with User/System filtering, search, sorting, and D-pad uninstallation.
3. An Apple tvOS-inspired lean launcher (`HomeActivity`) with top featured apps, rows, and remote-friendly navigation.
4. Live RAM and CPU system monitoring with background task termination.
5. In-app Quick Share local HTTP server with QR code pairing for direct mobile-to-TV transfer.

---

## 2. Phase Checklist

- [x] **PHASE 0 — ANALYSIS**
  - [x] Inspect project structure, manifest, build files, and dependencies
  - [x] Identify minSdk (26), targetSdk (34), compileSdk (35), UI stack (Compose + Material 3)
  - [x] Create `ARCHITECTURE.md`, `PROGRESS.md`, and `CHANGELOG.md`
  - [x] Confirm baseline build (`./gradlew assembleDebug` passes)
- [ ] **PHASE 1 — INSTALLED APPS LIST + UNINSTALL**
  - [ ] Add `REQUEST_DELETE_PACKAGES` and query permissions to manifest
  - [ ] Implement `InstalledApp` model, repository/scanner fetching package icon, name, version, size, install time
  - [ ] Add filter toggle (All / User / System), sort (Name, Size, Install Date), and search
  - [ ] Add D-pad focusable app cards and remote-friendly confirmation dialog for uninstall (`ACTION_DELETE`)
  - [ ] Gracefully handle system apps (disable/cannot uninstall indication)
- [ ] **PHASE 2 — CUSTOM LAUNCHER (Apple TV-STYLE HOME)**
  - [ ] Add `HomeActivity` with `MAIN`, `HOME`, `DEFAULT`, and `LEANBACK_LAUNCHER` intent filters
  - [ ] Implement Apple tvOS-style top featured row with focus scale, subtle glow/shadow, and background accent
  - [ ] Implement Favorites and All Apps grid/rows with 60fps focus and icon caching
  - [ ] Add top-corner clock and date
  - [ ] Add app launch fallback (`getLeanbackLaunchIntentForPackage` -> `getLaunchIntentForPackage`)
  - [ ] Add long-press / Menu action sheet (Open, Uninstall, App Info, Favorite)
  - [ ] Add "Set as default launcher" prompt and system settings intent
- [ ] **PHASE 3 — SYSTEM MONITOR (RAM + CPU) WITH KILL TASK**
  - [ ] Implement live RAM readout via `ActivityManager.MemoryInfo`
  - [ ] Implement resilient CPU monitor with graceful fallback on Android 10+
  - [ ] Implement running background processes list with memory consumption
  - [ ] Implement background process kill action (`ActivityManager.killBackgroundProcesses`) and "Clean All"
  - [ ] Bind polling to panel visibility lifecycle (stop updates when closed)
- [ ] **PHASE 4 — QUICK SHARE (BUILT INTO THE SIDE)**
  - [ ] Add collapsible side panel triggered by D-pad Left or dedicated toggle
  - [ ] Implement embedded lightweight HTTP server on local network
  - [ ] Generate on-screen QR code and PIN for pairing
  - [ ] Implement file upload receiver saving to `Downloads/LeanTV/`
  - [ ] Implement received text/link display with one-click open
- [ ] **PHASE 5 — POLISH, OPTIMIZATION, TESTING**
  - [ ] Cache app icons in memory to ensure fluid 60fps scrolling
  - [ ] Verify D-pad focus flows across all screens
  - [ ] Validate manifest features and permissions
  - [ ] Verify build and produce final APK and zip deliverables

---

## 3. Files Created or Modified

| File | Purpose |
| :--- | :--- |
| `ARCHITECTURE.md` | Documents system architecture, tech stack, and module layout. |
| `PROGRESS.md` | Tracks phase completion, active decisions, and resumption instructions. |
| `CHANGELOG.md` | Records chronological changes across development phases. |

---

## 4. Decisions, Known Issues, and Limitations

1. **Android TV Fixed Canvas Scaling:** The app relies on `TvCanvas` in `ui/Theme.kt` to scale density to a fixed 1280x720 reference grid. All new Compose layouts will respect this system for consistent TV overscan safety and legibility.
2. **Output Archive Directory:** Root `/output/` is protected under macOS SIP without root permissions. Phase archives are generated into both `<projectRoot>/output/` and `/tmp/output/` for user accessibility.
3. **App Listing Queries:** Android 11+ (API 30+) requires `QUERY_ALL_PACKAGES` to view user and system applications; already declared in `AndroidManifest.xml`.
4. **Package Uninstallation on TV:** Standard Android third-party apps cannot silently uninstall packages without system/root/device owner privileges. Uninstallation prompts the platform `PackageInstaller` via `Intent.ACTION_DELETE` or `PackageInstaller.Session`.

---

## 5. NEXT STEP (Resumption Guide)

If the session is interrupted:
- Proceed directly to **PHASE 1 — INSTALLED APPS LIST + UNINSTALL**.
- Implement the installed apps data model, repository, filter/sort state, and D-pad UI in `com.leantv.app.apps` and wire it into the navigation rail and screen router.
- Run `./gradlew assembleDebug` to verify compilation.
- Produce `LeanTV_phase1.zip`.
